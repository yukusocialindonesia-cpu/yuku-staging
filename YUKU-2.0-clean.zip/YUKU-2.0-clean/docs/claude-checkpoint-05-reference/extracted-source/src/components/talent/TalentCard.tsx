import React from 'react';
import { Star, MapPin, User as UserIcon } from 'lucide-react';
import { TalentProfile } from '../../types/talent';
import { formatRupiah } from '../../utils/formatters';

interface TalentCardProps {
  talent: TalentProfile;
  onSelect: (talentId: string) => void;
}

export const TalentCard: React.FC<TalentCardProps> = ({ talent, onSelect }) => {
  return (
    <article
      onClick={() => onSelect(talent.id)}
      className="group relative bg-white rounded-2xl border border-slate-200/90 overflow-hidden hover:border-purple-300 hover:shadow-lg transition-all duration-200 cursor-pointer flex flex-col"
    >
      {/* Top Media Container */}
      <div className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden flex items-center justify-center">
        {talent.avatarUrl ? (
          <img
            src={talent.avatarUrl}
            alt={`Foto profil ${talent.name}`}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        ) : (
          <UserIcon className="w-16 h-16 text-slate-300" />
        )}

        {/* Subtle contrast gradient at the bottom */}
        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-slate-950/70 via-slate-950/20 to-transparent" />

        {/* Location & Service mode overlay at bottom */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-white text-xs font-medium">
          {talent.city ? (
            <span className="flex items-center gap-1 drop-shadow-xs">
              <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{talent.city}</span>
            </span>
          ) : (
            <span />
          )}
          {talent.serviceMode && (
            <span className="text-[11px] bg-slate-900/75 backdrop-blur-xs px-2 py-0.5 rounded text-slate-200">
              {talent.serviceMode}
            </span>
          )}
        </div>
      </div>

      {/* Body Information */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Header Row: Name, Age, Rating */}
          <div className="flex items-baseline justify-between gap-2 mb-1">
            <h3 className="font-bold text-slate-900 text-lg group-hover:text-purple-700 transition-colors">
              {talent.name}{talent.age ? `, ${talent.age}` : ''}
            </h3>
            {talent.rating !== undefined && (
              <div className="flex items-center gap-1 text-xs font-semibold text-slate-700 tabular-nums">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span>{talent.rating.toFixed(1)}</span>
                {talent.reviewCount !== undefined && (
                  <span className="text-slate-400 font-normal">({talent.reviewCount})</span>
                )}
              </div>
            )}
          </div>

          {/* Headline */}
          {talent.headline && (
            <p className="text-sm font-medium text-purple-900/90 line-clamp-1 mb-2">
              {talent.headline}
            </p>
          )}

          {/* Short Bio */}
          {talent.bio && (
            <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-4">
              {talent.bio}
            </p>
          )}

          {/* Unboxed Metadata: Interests */}
          {talent.interests && talent.interests.length > 0 && (
            <div className="text-xs text-slate-500 flex flex-wrap items-center gap-x-2 gap-y-1 mb-4">
              <span className="font-medium text-slate-700">Minat:</span>
              {talent.interests.slice(0, 3).map((item, idx) => (
                <React.Fragment key={item}>
                  {idx > 0 && <span aria-hidden="true">·</span>}
                  <span>{item}</span>
                </React.Fragment>
              ))}
            </div>
          )}
        </div>

        {/* Footer Row: Rates & CTA */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">Tarif</span>
            <div className="text-sm font-extrabold text-[#1E0938] tabular-nums">
              {talent.hourlyRate ? formatRupiah(talent.hourlyRate) : 'Hubungi Talent'}
              {talent.hourlyRate ? <span className="text-xs font-normal text-slate-500"> / jam</span> : null}
            </div>
          </div>

          <button
            type="button"
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-purple-700 to-fuchsia-700 hover:from-purple-800 hover:to-fuchsia-800 rounded-lg transition-all shadow-xs shrink-0"
          >
            Lihat Profil
          </button>
        </div>
      </div>
    </article>
  );
};
