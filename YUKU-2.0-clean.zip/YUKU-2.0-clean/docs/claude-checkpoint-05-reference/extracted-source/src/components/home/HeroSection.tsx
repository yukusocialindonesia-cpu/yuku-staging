import React from 'react';
import { ArrowRight, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { SearchActivityWidget } from './SearchActivityWidget';

interface HeroSectionProps {
  onExploreClick: () => void;
  onSearch: (activity: string, city: string) => void;
  onRegisterCustomerClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreClick,
  onSearch,
  onRegisterCustomerClick,
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 md:pt-14 md:pb-24 bg-gradient-to-b from-purple-50/70 via-white to-[#FAF8FC]">
      {/* Subtle background ambient mesh */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-purple-200/30 via-fuchsia-100/30 to-amber-100/20 blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Anti-dating / Safety assurance header line (Quiet unboxed text) */}
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-purple-100/70 border border-purple-200/80 rounded-full text-purple-900 text-xs font-semibold mb-6">
          <ShieldCheck className="w-3.5 h-3.5 text-purple-700" />
          <span>Social Experience & Paid Companionship Marketplace Pertama di Indonesia</span>
        </div>

        {/* Tagline & Main Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-[#1E0938] tracking-tight max-w-4xl mx-auto leading-[1.12] mb-6">
          Real Friends.{' '}
          <span className="bg-gradient-to-r from-purple-700 via-fuchsia-600 to-amber-500 bg-clip-text text-transparent">
            Real Moments.
          </span>
        </h1>

        {/* Subtitle / Description */}
        <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto mb-8 leading-relaxed font-normal">
          Temukan pendamping aktivitas terpercaya untuk menemani ngopi, nonton film, jalan santai, menghadiri acara penting, hingga teman mengobrol online yang hangat dan bersahabat.
        </p>

        {/* Primary CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 mb-12">
          <button
            onClick={onExploreClick}
            className="w-full sm:w-auto px-7 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-purple-700 via-fuchsia-700 to-amber-600 hover:from-purple-800 hover:to-amber-700 rounded-xl shadow-lg shadow-purple-900/15 hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Jelajahi Talent Sekarang</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onRegisterCustomerClick}
            className="w-full sm:w-auto px-6 py-3.5 text-sm font-semibold text-purple-900 bg-white hover:bg-purple-50/80 border border-purple-200 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Daftar Akun Customer</span>
            <span className="text-xs text-purple-700 font-bold bg-purple-100 px-2 py-0.5 rounded">
              Gratis
            </span>
          </button>
        </div>

        {/* Search Widget */}
        <div className="mt-4">
          <SearchActivityWidget onSearch={onSearch} />
        </div>

        {/* Trust Points adjacent to Hero */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-slate-500">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-600" />
            100% Ruang Publik & Aman
          </span>
          <span className="hidden sm:inline" aria-hidden="true">·</span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-fuchsia-600" />
            Bukan Aplikasi Kencan / No Dating
          </span>
          <span className="hidden sm:inline" aria-hidden="true">·</span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            Verifikasi Usia Wajib 18+
          </span>
        </div>
      </div>
    </section>
  );
};
