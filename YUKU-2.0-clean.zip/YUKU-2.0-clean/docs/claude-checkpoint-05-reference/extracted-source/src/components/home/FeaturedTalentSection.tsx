import React, { useEffect, useState } from 'react';
import { ArrowRight, AlertCircle, RefreshCw, Users } from 'lucide-react';
import { TalentProfile } from '../../types/talent';
import { TalentCard } from '../talent/TalentCard';
import { fetchTalentsFromSupabase } from '../../utils/supabaseMarketplace';

interface FeaturedTalentSectionProps {
  onSelectTalent: (talentId: string) => void;
  onViewAllClick: () => void;
}

export const FeaturedTalentSection: React.FC<FeaturedTalentSectionProps> = ({
  onSelectTalent,
  onViewAllClick,
}) => {
  const [talents, setTalents] = useState<TalentProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadFeaturedTalents = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await fetchTalentsFromSupabase(6);
      setTalents(data);
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal memuat data Talent dari Supabase.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFeaturedTalents();
  }, []);

  return (
    <section className="py-16 bg-[#FAF8FC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-purple-700 tracking-wider uppercase mb-1 block">
              Kurasi Pilihan Terverifikasi
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Talent Pilihan di Kotamu
            </h2>
          </div>
          <button
            onClick={onViewAllClick}
            className="inline-flex items-center gap-1.5 text-sm font-bold text-purple-800 hover:text-purple-950 transition-colors cursor-pointer"
          >
            <span>Lihat Semua Talent</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-80 rounded-2xl bg-slate-200 animate-pulse" />
            ))}
          </div>
        ) : errorMsg ? (
          <div className="p-6 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
            <button
              onClick={loadFeaturedTalents}
              className="px-3 py-1.5 bg-rose-600 text-white rounded-lg font-bold flex items-center gap-1 hover:bg-rose-700 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Coba Lagi</span>
            </button>
          </div>
        ) : talents.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
            <Users className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <p>Belum ada profil Talent aktif yang terdaftar di Supabase.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {talents.map((talent) => (
              <TalentCard
                key={talent.id}
                talent={talent}
                onSelect={onSelectTalent}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
