import React from 'react';
import { HOW_IT_WORKS_STEPS } from '../../utils/contentData';
import { ArrowRight } from 'lucide-react';

interface HowItWorksSectionProps {
  onLearnMoreClick: () => void;
}

export const HowItWorksSection: React.FC<HowItWorksSectionProps> = ({ onLearnMoreClick }) => {
  return (
    <section className="py-20 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-bold text-purple-700 tracking-wider uppercase mb-2 block">
            Alur Mudah & Transparan
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E0938] tracking-tight mb-4">
            Cara Kerja YUKU
          </h2>
          <p className="text-slate-600 text-sm sm:text-base">
            Empat langkah sederhana untuk menikmati waktu santai, kegiatan berkesan, dan obrolan seru bersama teman baru.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {HOW_IT_WORKS_STEPS.map((item, index) => (
            <div key={item.step} className="relative flex flex-col">
              {/* Natural editorial numbering */}
              <div className="text-4xl font-black text-purple-200/90 mb-3 tracking-tighter">
                {item.step}
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                {item.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={onLearnMoreClick}
            className="inline-flex items-center gap-2 text-sm font-bold text-purple-700 hover:text-purple-900 transition-colors cursor-pointer"
          >
            <span>Pelajari Pedoman Etika & Panduan Lengkap</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
