import React from 'react';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { SafetyPledgeBanner } from '../components/common/SafetyPledgeBanner';
import { AppRoute } from '../types/navigation';

interface MainLayoutProps {
  currentPath: string;
  onNavigate: (path: AppRoute) => void;
  children: React.ReactNode;
}

export const MainLayout: React.FC<MainLayoutProps> = ({
  currentPath,
  onNavigate,
  children,
}) => {
  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8FC] text-slate-800">
      {/* Main navigation header */}
      <Navbar currentPath={currentPath} onNavigate={onNavigate} />

      {/* Main content body */}
      <main className="flex-1">{children}</main>

      {/* Reassuring safety pledge before footer */}
      <SafetyPledgeBanner />

      {/* Site footer */}
      <Footer onNavigate={onNavigate} />
    </div>
  );
};
