# YUKU 2.0 — Real Friends. Real Moments.

Marketplace jasa pertemanan untuk pengalaman sosial online dan offline.

## Stack saat ini

- React 19 + TypeScript
- Vite 8
- Supabase (Auth, Postgres, Storage, Realtime)

> Proyek ini masih berupa aplikasi React + Vite. Migrasi ke Next.js belum dilakukan.
> Jangan menganggap proyek siap produksi sebelum seluruh migrasi database dan pengujian staging lulus.

## Menjalankan lokal

1. Gunakan Node.js 22 atau versi yang kompatibel dengan Vite 8.
2. Jalankan `npm install`.
3. Salin `.env.example` menjadi `.env.local`.
4. Isi `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` (atau `VITE_SUPABASE_PUBLISHABLE_KEY`) dari proyek Supabase milik YUKU.
5. Jalankan `npm run dev`.

Tanpa konfigurasi Supabase, aplikasi sengaja tidak akan tersambung ke proyek default apa pun.

## Database

Baca `supabase/migrations/README.md`. Migrasi harus diterapkan berurutan pada proyek staging terlebih dahulu. `supabase/FULL_MIGRATION_V20.sql` adalah file pensiun berisi peringatan saja; jangan dieksekusi.

## Deploy

Lihat `docs/PRELAUNCH-CHECKLIST.md`. Singkatnya: `npm install`, `npm run typecheck`, `npm run build`; terapkan migrasi 01-23 di staging; jalankan `supabase/tests/*` dan `supabase/ops/post_deploy_checks.sql`; deploy Edge Function di `supabase/functions/` (`create-checkout`, dan `xendit-webhook` dengan `--no-verify-jwt`).

## Status kesiapan

Belum production-ready. Payment gateway, webhook, dan payout provider otomatis belum terintegrasi atau diuji pada lingkungan staging.

## Batas integrasi keuangan saat ini

- Payout dan refund masih menggunakan proses manual dengan pencatatan referensi transfer; API provider belum dihubungkan.
- Payment gateway, pembuatan invoice/checkout, dan verifikasi webhook belum tersedia.
- Booking publik dinonaktifkan secara default (`VITE_PAYMENT_CHECKOUT_ENABLED=false`) sampai checkout dan webhook payment gateway dipasang serta diuji. Booking baru berstatus `pending_payment` sampai pembayaran terverifikasi.
- Refund pembatalan oleh Talent membuat permintaan refund penuh; proses pengembalian aktual tetap harus dilakukan Finance di provider/bank.
- Kebijakan pembatalan Customer untuk booking yang sudah dibayar (100% / 50% / peninjauan di bawah 6 jam) belum diimplementasikan sampai alokasi dana sisa 50% ditetapkan secara akuntansi.
